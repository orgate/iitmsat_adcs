
syms X hm w0 I N_ext;
syms q1 q2 q3 q4 w1 w2 w3;
syms Ix Iy Iz;
syms hm1 hm2 hm3;

X=[q1;q2;q3;q4;w1;w2;w3];
I=[Ix 0 0;0 Iy 0;0 0 Iz];
hm=[hm1;hm2;hm3];
p=input('Enter Linearization Point: (7x1 vector)');
J=jacobian(normal_nonlinear(X,hm,w0,I,N_ext),X)
A=subs(J, X, p)
