function X_dot=normal_nonlinear(X,hm,w0,I,N_ext)

%define q and w form X
q=[X(1); X(2); X(3); X(4)];
w=[X(5);X(6);X(7)];

%define h
h=I*w;

%Calculate q_dot from q and P
v=[w;0]-quaternion_multiply(quaternion_multiply(quaternion_inverse(q),[0;w0;0;0]),q);
P=[0 v(3) -v(2) v(1);-v(3) 0 v(1) v(2);v(2) -v(1) 0 v(3);-v(1) -v(2) -v(3) 0];
q_dot=0.5*P*q;

%Calculate q_dot **B (earth's Magnetic field) is in Orbit coordinate System(OCS)**
temp=I\(hm-N_ext-(I\(h-hm)));
w_dot=-skew_sym(temp)*h;

%calculate X_dot
X_dot=[q_dot;w_dot];
end
